class Math {
  constructor() {
  }

  getCurrentValue() {
  }

  calc(action, value) {
  }
}

export default Math;
